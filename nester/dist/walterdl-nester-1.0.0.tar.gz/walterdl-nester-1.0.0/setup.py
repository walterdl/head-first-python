from distutils.core import setup

setup(
  name='walterdl-nester',
  version='1.0.0',
  py_modules=['nester'],
  author='Walter Devia',
  author_email='walter.devia@outlook.com',
  url='https://walterdevia.com',
  description='My first python distributed function coming from Head First Python book'
)